//
//  ViewController.swift
//  MVPProject
//
//  Created by Владислав  on 25.02.2024.
//

import UIKit

class ViewController: UIViewController, PresentView {
    
    
    func updateLabel() {
        simpleLabel.text = "Hello, World!"
        view.backgroundColor = .lightGray
    }
    

    
    @IBOutlet weak var ourButton: UIButton!
    
    @IBOutlet weak var simpleLabel: UILabel!
    
    lazy var presenter = Presenter(ourView: self)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func ourButtonAction(_ sender: UIButton) {
        presenter.buttonTaped()
    }
    
}

