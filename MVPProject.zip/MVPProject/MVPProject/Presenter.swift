//
//  Presenter.swift
//  MVPProject
//
//  Created by Владислав  on 25.02.2024.
//

import Foundation

protocol PresentView {
    
    func updateLabel() 
        
    
}
class Presenter {
    var ourView: PresentView?
    init(ourView: PresentView) {
        self.ourView = ourView
    }
    
    var timesTaped = 0
    
    func buttonTaped() {
        timesTaped += 1
        if timesTaped >= 3 {
            self.ourView?.updateLabel()
        }
    }
}
